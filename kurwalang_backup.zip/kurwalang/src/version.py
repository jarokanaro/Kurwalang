"""Single source of truth for the KURWA LANG version."""

LANGUAGE_VERSION = "1.12.0"
