# KURWA LANG Standard Library

Standard library v1.0 jest dostarczana przez backend interpretera i ładowana przez istniejący `ModuleLoader`. Publiczne namespace'y to:

- `matematyka`
- `losuj`
- `tekst`
- `czas`
- `system`

Nie są to pliki użytkownika `.kurwa`, więc lokalny moduł o tej samej nazwie nie nadpisuje standard library. Szczegółowy kontrakt API znajduje się w [docs/stdlib.md](../docs/stdlib.md).
