# Operatory

## Matematyczne

`+`, `-`, `*`, `/` działają na liczbach całkowitych. Dzielenie przez zero zgłasza błąd KURWA LANG.

`+` działa także dla dwóch stringów i zwraca ich połączenie. Mieszanie stringa z numberem jest błędem.

## Porównania

`<`, `>`, `<=`, `>=` wymagają liczb. `==` i `!=` porównują wartości tego samego typu; różne typy są nierówne.

## Logiczne

- `nie` - negacja boolean,
- `i` - AND z short-circuit,
- `albo` - OR z short-circuit.

Priorytet od najwyższego:

1. nawiasy,
2. `nie`,
3. `*`, `/`,
4. `+`, `-`,
5. porównania,
6. `i`,
7. `albo`.
