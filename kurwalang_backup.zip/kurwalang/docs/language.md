# KURWA LANG

KURWA LANG jest interpretowanym językiem z polską, slangową składnią. Backend interpretera jest napisany w Pythonie.

## Dostępne elementy

- zmienne przez `kurwa`,
- liczby, stringi, booleany, listy i mapy,
- działania matematyczne i porównania,
- logika `i`, `albo`, `nie`,
- `jeśli` i `inaczej`,
- pętle `dopóki` i `wypierdalaj`,
- funkcje `odpierdol funkcja` i `oddaj`,
- listy i mapy indeksowane przez `[...]`,
- built-iny `ile_kurwa` i `jest_kurwa`,
- wypisywanie przez `wypierdol`, `pierdol` i `co_jest_kurwa`.
- moduły `.kurwa` importowane przez `zajeb_moduł` i namespace z kropką.

## Uruchomienie

```bash
python3 src/main.py examples/maps.kurwa
python3 -m unittest discover -s tests
```

Pliki `.kurwa` są kodem źródłowym KURWA LANG.

## Moduły

moduły `.kurwa` importowane przez `zajeb_moduł` i namespace z kropką.
